export const DEMO_PRESETS = [
  {
    id: "hanoi-8",
    name: "Hà Nội · 8 khách",
    depot: { id: 0, name: "Kho trung tâm", lat: 21.0278, lng: 105.8342, open_time: "08:00", close_time: "17:00" },
    vehicle: { number: 2, capacity: 70 },
    customers: [
      { id: 1, name: "KH 01", lat: 21.0307, lng: 105.8336, demand: 15, ready_time: "08:00", due_time: "09:30", service_time: 10 },
      { id: 2, name: "KH 02", lat: 21.0356, lng: 105.8421, demand: 20, ready_time: "08:30", due_time: "10:30", service_time: 10 },
      { id: 3, name: "KH 03", lat: 21.0218, lng: 105.8447, demand: 10, ready_time: "09:00", due_time: "11:00", service_time: 10 },
      { id: 4, name: "KH 04", lat: 21.0292, lng: 105.8508, demand: 25, ready_time: "09:30", due_time: "12:00", service_time: 15 },
      { id: 5, name: "KH 05", lat: 21.0411, lng: 105.8297, demand: 15, ready_time: "10:00", due_time: "12:30", service_time: 10 },
      { id: 6, name: "KH 06", lat: 21.0179, lng: 105.8362, demand: 20, ready_time: "10:30", due_time: "13:00", service_time: 10 },
      { id: 7, name: "KH 07", lat: 21.0338, lng: 105.8602, demand: 10, ready_time: "11:00", due_time: "14:00", service_time: 10 },
      { id: 8, name: "KH 08", lat: 21.0129, lng: 105.8498, demand: 20, ready_time: "12:00", due_time: "15:00", service_time: 15 }
    ]
  },
  {
    id: "hanoi-15",
    name: "Hà Nội · 15 khách",
    depot: { id: 0, name: "Kho trung tâm", lat: 21.0278, lng: 105.8342, open_time: "08:00", close_time: "17:00" },
    vehicle: { number: 5, capacity: 75 },
    customers: [
      { id: 1, lat: 21.0307, lng: 105.8336, demand: 15, ready_time: "08:00", due_time: "09:30", service_time: 10 },
      { id: 2, lat: 21.0356, lng: 105.8421, demand: 20, ready_time: "08:15", due_time: "10:15", service_time: 10 },
      { id: 3, lat: 21.0218, lng: 105.8447, demand: 10, ready_time: "08:30", due_time: "11:00", service_time: 10 },
      { id: 4, lat: 21.0292, lng: 105.8508, demand: 25, ready_time: "09:00", due_time: "11:30", service_time: 15 },
      { id: 5, lat: 21.0411, lng: 105.8297, demand: 15, ready_time: "09:30", due_time: "12:00", service_time: 10 },
      { id: 6, lat: 21.0179, lng: 105.8362, demand: 20, ready_time: "10:00", due_time: "12:30", service_time: 10 },
      { id: 7, lat: 21.0338, lng: 105.8602, demand: 10, ready_time: "10:15", due_time: "13:00", service_time: 10 },
      { id: 8, lat: 21.0129, lng: 105.8498, demand: 20, ready_time: "10:30", due_time: "13:30", service_time: 15 },
      { id: 9, lat: 21.0453, lng: 105.8541, demand: 15, ready_time: "11:00", due_time: "14:00", service_time: 10 },
      { id: 10, lat: 21.0197, lng: 105.8237, demand: 20, ready_time: "11:00", due_time: "14:30", service_time: 10 },
      { id: 11, lat: 21.0394, lng: 105.8159, demand: 10, ready_time: "11:30", due_time: "15:00", service_time: 10 },
      { id: 12, lat: 21.0078, lng: 105.8337, demand: 25, ready_time: "12:00", due_time: "15:30", service_time: 15 },
      { id: 13, lat: 21.0504, lng: 105.8382, demand: 15, ready_time: "12:30", due_time: "16:00", service_time: 10 },
      { id: 14, lat: 21.0248, lng: 105.8677, demand: 20, ready_time: "13:00", due_time: "17:00", service_time: 10 },
      { id: 15, lat: 21.0007, lng: 105.8487, demand: 15, ready_time: "13:30", due_time: "17:30", service_time: 10 }
    ]
  }
];

export function clonePreset(preset) {
  return JSON.parse(JSON.stringify(preset));
}
